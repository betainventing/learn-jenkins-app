#!/usr/bin/bash
git pull
git add .
git commit -m "adding code."
git push
